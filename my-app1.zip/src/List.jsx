import React from "react";
const List = (props) => {
    return (
    <div>
    <div>
    
    <li> {props.text} </li>
    </div>
    </div>
    ) ;
};
export default List;