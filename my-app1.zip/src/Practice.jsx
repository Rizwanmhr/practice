// import React, {useState} from "react";
// const Practice = () => {

//     let time = new Date().toLocaleTimeString();
//     let [ctime,setcTime] = useState(time);

//     let Updatetime = () => {
//         let time = new Date().toLocaleTimeString();
//         setcTime(time); 
//     } ;
//     setInterval(Updatetime,1000);

// return(
// <div>
//     <h1> {ctime} </h1>
// </div>
// );
// };
// export default Practice;
