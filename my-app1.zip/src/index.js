import React from "react";
import ReactDom from "react-dom";
import "./index.css";
import Todo from "./Todo";

ReactDom.render(<Todo />,

    document.getElementById("root"));
   
